Uruchomienie projektu:

System Windows - Plik wsadowy SerwisMuzyczny.bat uruchamia program

System Linux - Skrypt pow�oki bash SerwisMuzyczny.exe uruchamia program
	       Awaryjnie z poziomu linii polece� komenda: java -jar SerwisMuzyczny.jar


W projekcie u�ytkownik mo�e utworzy� tylko zwyk�e konto, cz�� funkcjonalno�ci dla administrator�w.
Dane do testowego konta na prawach administratora:
Nazwa u�ytkownika: Admin
Has�o: test